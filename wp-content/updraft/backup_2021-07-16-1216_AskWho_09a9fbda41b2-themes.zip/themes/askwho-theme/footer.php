<!-- <section class="footer" id="section_6" attr_bg="#f0e97c" style="background-color:#f0e97c">
    <div class="container_ask_who">
        <a href="<?php echo site_url(); ?>">
            <img src="<?php echo get_stylesheet_directory_uri() . '/assets/images/Logo_AskWho.png'; ?>"
                alt="<?php echo get_bloginfo('name'); ?>" class="logo">
        </a>
    </div>
</section> -->
<?php wp_footer();?>
</body>

</html>
<?php ob_end_flush();?>