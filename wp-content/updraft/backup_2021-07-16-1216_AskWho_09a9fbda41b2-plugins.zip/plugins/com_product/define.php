<?php
define('PLUGIN_PATH', plugin_dir_path(__FILE__));
define('PLUGIN_URL', plugin_dir_url(__FILE__));
define('ZENDVN_SP_PLUGIN_NAME', 'ZENDVN_SP');
define('ZENDVN_SP_PLUGIN_VERSION', '1.0');
define("PATTERN_EMAIL", "#^[a-z][a-z0-9_\.]{4,31}@[a-z0-9]{2,}(\.[a-z0-9]{2,4}){1,2}$#");