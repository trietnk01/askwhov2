<?php
require_once trailingslashit(get_stylesheet_directory()) . 'add-acf-setting-page.php';
require_once trailingslashit(get_stylesheet_directory()) . 'add-acf-init-block-types.php';
require_once trailingslashit(get_stylesheet_directory()) . 'add-css-js-src.php';
require_once trailingslashit(get_stylesheet_directory()) . 'add-common-func.php';
require_once trailingslashit(get_stylesheet_directory()) . 'add-theme-support.php';